import os
import sqlite3


def conectar(caminho):
    banco = sqlite3.connect(caminho)
    banco.row_factory = sqlite3.Row
    banco.execute("PRAGMA foreign_keys = ON")
    return banco


def inicializar_banco(caminho):
    pasta = os.path.dirname(os.path.abspath(caminho))
    os.makedirs(pasta, exist_ok=True)
    pasta_sql = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "database"))
    banco = conectar(caminho)

    for nome in ("01_modelo_fisico.sql", "02_insercoes_basicas.sql", "20_triggers.sql"):
        with open(os.path.join(pasta_sql, nome), encoding="utf-8") as arquivo:
            banco.executescript(arquivo.read())

    # Atualiza o nome da coluna para indicar que a senha fica criptografada.
    colunas_usuarios = [linha[1] for linha in banco.execute("PRAGMA table_info(usuarios)")]
    if "senha_hash" in colunas_usuarios and "senha_criptografada" not in colunas_usuarios:
        banco.execute("ALTER TABLE usuarios RENAME COLUMN senha_hash TO senha_criptografada")

    # Acrescenta o tempo estimado sem apagar bancos já existentes.
    colunas = [linha[1] for linha in banco.execute("PRAGMA table_info(pedidos)")]
    if "tempo_estimado" not in colunas:
        banco.execute("ALTER TABLE pedidos ADD COLUMN tempo_estimado INTEGER DEFAULT 0")

    banco.commit()
    banco.close()


def criar_senha(senha_criptografada):
    """Recebe a senha ja criptografada com AES no navegador."""
    return senha_criptografada


def verificar_senha(senha_criptografada, senha_salva):
    """Compara o texto AES recebido com o valor salvo no banco."""
    return senha_criptografada == senha_salva
