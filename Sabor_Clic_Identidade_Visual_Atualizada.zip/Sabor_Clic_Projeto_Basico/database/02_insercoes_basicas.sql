-- Contas de demonstração.
-- Senha de todas as contas: Demo123!

INSERT OR IGNORE INTO usuarios
(id, nome, email, senha_criptografada, papel)
VALUES
(1, 'Administrador Demo', 'admin@saborclic.local',
 'GT9tnyq84RZ1DOo07LMdOA==', 'ADMIN');

INSERT OR IGNORE INTO usuarios
(id, nome, email, senha_criptografada, papel)
VALUES
(2, 'Cliente Demo', 'cliente@saborclic.local',
 'GT9tnyq84RZ1DOo07LMdOA==', 'CLIENTE');

INSERT OR IGNORE INTO usuarios
(id, nome, email, senha_criptografada, papel)
VALUES
(3, 'Cozinheiro Demo', 'cozinha@saborclic.local',
 'GT9tnyq84RZ1DOo07LMdOA==', 'COZINHEIRO');


INSERT OR IGNORE INTO espacos
(id, nome, tipo, descricao, capacidade, valor_hora, endereco, equipamentos, ativo)
VALUES
(1, 'Cozinha Profissional Centro', 'DARK_KITCHEN',
 'Cozinha independente equipada para operações de delivery.',
 6, 65.00, 'Centro - São Paulo/SP',
 'Fogão industrial, coifa, bancadas e refrigeração', 1);

INSERT OR IGNORE INTO espacos
(id, nome, tipo, descricao, capacidade, valor_hora, endereco, equipamentos, ativo)
VALUES
(2, 'Bancada Compartilhada 02', 'BANCADA',
 'Estação individual para produção gastronômica.',
 2, 28.00, 'Vila Mariana - São Paulo/SP',
 'Bancada inox, pia e tomadas', 1);

INSERT OR IGNORE INTO espacos
(id, nome, tipo, descricao, capacidade, valor_hora, endereco, equipamentos, ativo)
VALUES
(3, 'Cozinha Compartilhada Norte', 'COZINHA_COMPARTILHADA',
 'Ambiente compartilhado com estrutura profissional.',
 8, 48.00, 'Santana - São Paulo/SP',
 'Fornos, geladeiras e pias', 1);


-- Pratos de demonstração do cardápio.
INSERT OR IGNORE INTO itens_cardapio (id, espaco_id, nome, descricao, preco, ativo)
VALUES (1, 1, 'Marmita caseira', 'Arroz, feijão, legumes e acompanhamento.', 24.90, 1);
INSERT OR IGNORE INTO itens_cardapio (id, espaco_id, nome, descricao, preco, ativo)
VALUES (2, 1, 'Massa ao molho', 'Massa com molho de tomate.', 22.00, 1);
INSERT OR IGNORE INTO itens_cardapio (id, espaco_id, nome, descricao, preco, ativo)
VALUES (3, 1, 'Salada completa', 'Salada com legumes variados.', 18.50, 1);

-- Estoque simples para demonstrar a baixa automática.
INSERT OR IGNORE INTO estoque (id, nome, quantidade) VALUES (1, 'Porções de arroz', 40);
INSERT OR IGNORE INTO estoque (id, nome, quantidade) VALUES (2, 'Porções de feijão', 40);
INSERT OR IGNORE INTO estoque (id, nome, quantidade) VALUES (3, 'Porções de massa', 30);
INSERT OR IGNORE INTO estoque (id, nome, quantidade) VALUES (4, 'Porções de salada', 30);

INSERT OR IGNORE INTO item_estoque (item_id, estoque_id, quantidade_por_item) VALUES (1, 1, 1);
INSERT OR IGNORE INTO item_estoque (item_id, estoque_id, quantidade_por_item) VALUES (1, 2, 1);
INSERT OR IGNORE INTO item_estoque (item_id, estoque_id, quantidade_por_item) VALUES (2, 3, 1);
INSERT OR IGNORE INTO item_estoque (item_id, estoque_id, quantidade_por_item) VALUES (3, 4, 1);


-- Pratos de demonstração do cardápio.
INSERT OR IGNORE INTO itens_cardapio (id, espaco_id, nome, descricao, preco, ativo)
VALUES (1, 1, 'Marmita caseira', 'Arroz, feijão, legumes e acompanhamento.', 24.90, 1);
INSERT OR IGNORE INTO itens_cardapio (id, espaco_id, nome, descricao, preco, ativo)
VALUES (2, 1, 'Massa ao molho', 'Massa com molho de tomate.', 22.00, 1);
INSERT OR IGNORE INTO itens_cardapio (id, espaco_id, nome, descricao, preco, ativo)
VALUES (3, 1, 'Salada completa', 'Salada com legumes variados.', 18.50, 1);

-- Estoque simples para demonstrar a baixa automática.
INSERT OR IGNORE INTO estoque (id, nome, quantidade) VALUES (1, 'Porções de arroz', 40);
INSERT OR IGNORE INTO estoque (id, nome, quantidade) VALUES (2, 'Porções de feijão', 40);
INSERT OR IGNORE INTO estoque (id, nome, quantidade) VALUES (3, 'Porções de massa', 30);
INSERT OR IGNORE INTO estoque (id, nome, quantidade) VALUES (4, 'Porções de salada', 30);

INSERT OR IGNORE INTO item_estoque (item_id, estoque_id, quantidade_por_item) VALUES (1, 1, 1);
INSERT OR IGNORE INTO item_estoque (item_id, estoque_id, quantidade_por_item) VALUES (1, 2, 1);
INSERT OR IGNORE INTO item_estoque (item_id, estoque_id, quantidade_por_item) VALUES (2, 3, 1);
INSERT OR IGNORE INTO item_estoque (item_id, estoque_id, quantidade_por_item) VALUES (3, 4, 1);
