document.addEventListener("DOMContentLoaded", async () => {
    const lista = document.querySelector("#lista-pratos");
    const mensagem = document.querySelector("#mensagem-cardapio");
    const formulario = document.querySelector("#form-prato");
    const seletorEspaco = document.querySelector("#espaco-prato");
    const areaAdmin = document.querySelector("#area-admin-cardapio");

    async function carregar() {
        try {
            const [pratos, sessao, espacos] = await Promise.all([
                chamarApi("/api/cardapio"),
                chamarApi("/api/auth/sessao"),
                chamarApi("/api/espacos")
            ]);

            areaAdmin.hidden = !sessao || sessao.papel !== "ADMIN";
            seletorEspaco.innerHTML = '<option value="">Selecione</option>';
            espacos.forEach(espaco => seletorEspaco.add(new Option(espaco.nome, espaco.id)));
            lista.innerHTML = "";

            if (pratos.length === 0) {
                lista.textContent = "Nenhum prato cadastrado.";
                return;
            }

            pratos.forEach(dados => {
                const prato = new Prato(dados);
                const cartao = document.createElement("article");
                cartao.className = "cartao";
                const titulo = document.createElement("h3");
                titulo.textContent = prato.nome;
                const descricao = document.createElement("p");
                descricao.textContent = prato.descricao || "";
                const preco = document.createElement("strong");
                preco.textContent = `R$ ${prato.preco.toFixed(2).replace(".", ",")}`;
                cartao.append(titulo, descricao, preco);
                if (sessao && sessao.papel === "CLIENTE") {
                    const link = document.createElement("a");
                    link.href = "/pedidos";
                    link.className = "botao";
                    link.textContent = "Ir para o carrinho";
                    cartao.appendChild(link);
                }
                if (sessao && sessao.papel === "ADMIN") {
                    const remover = document.createElement("button");
                    remover.textContent = "Desativar prato";
                    remover.addEventListener("click", async () => {
                        try {
                            await chamarApi(`/api/cardapio/${prato.id}`, { method: "DELETE" });
                            document.addEventListener("sessaoAlterada", carregar);
    carregar();
                        } catch (erro) { mensagem.textContent = erro.message; }
                    });
                    cartao.appendChild(remover);
                }
                lista.appendChild(cartao);
            });
        } catch (erro) {
            mensagem.textContent = erro.message;
        }
    }

    formulario.addEventListener("submit", async evento => {
        evento.preventDefault();
        const dados = Object.fromEntries(new FormData(formulario));
        try {
            await chamarApi("/api/cardapio", { method: "POST", body: JSON.stringify(dados) });
            mensagem.textContent = "Prato cadastrado.";
            formulario.reset();
            carregar();
        } catch (erro) { mensagem.textContent = erro.message; }
    });

    carregar();
});
