document.addEventListener("DOMContentLoaded", function () {
    const mensagem = document.querySelector("#mensagem-painel");
    const tabela = document.querySelector("#tabela-reservas");
    const botaoAtualizar = document.querySelector("#atualizar-reservas");
    const formulario = document.querySelector("#form-espaco");
    const areaCadastro = document.querySelector("#area-cadastro-espaco");

    async function atualizarPermissoes() {
        try {
            const usuario = await chamarApi("/api/auth/sessao");
            areaCadastro.hidden = !usuario || !(usuario.papel === "ADMIN" || usuario.papel === "EMPRESA");
        } catch (erro) {
            areaCadastro.hidden = true;
        }
    }

    // Busca as reservas e monta a tabela.
    async function carregarReservas() {
        try {
            const reservas = await chamarApi("/api/reservas");

            mensagem.textContent = reservas.length + " reserva(s) encontrada(s).";

            tabela.innerHTML = "";

            if (reservas.length === 0) {
                tabela.textContent = "Não existem reservas cadastradas.";
                return;
            }

            const tabelaHtml = document.createElement("table");

            tabelaHtml.innerHTML = `
                <tr>
                    <th>Cliente</th>
                    <th>Espaço</th>
                    <th>Período</th>
                    <th>Finalidade</th>
                    <th>Status</th>
                    <th>Ações</th>
                </tr>
            `;

            reservas.forEach(function (reserva) {
                const linha = document.createElement("tr");

                const cliente = document.createElement("td");
                cliente.textContent = reserva.nome_cliente;

                const espaco = document.createElement("td");
                espaco.textContent = reserva.nome_espaco;

                const periodo = document.createElement("td");
                periodo.textContent =
                    reserva.data_inicio + " até " + reserva.data_fim;

                const finalidade = document.createElement("td");
                finalidade.textContent = reserva.finalidade;

                const status = document.createElement("td");
                status.textContent = reserva.status;

                const acoes = document.createElement("td");

                if (reserva.status === "PENDENTE") {
                    const aprovar = document.createElement("button");
                    aprovar.textContent = "Aprovar";
                    aprovar.addEventListener("click", function () {
                        alterarStatus(reserva.id, "APROVADA");
                    });

                    const recusar = document.createElement("button");
                    recusar.textContent = "Recusar";
                    recusar.addEventListener("click", function () {
                        alterarStatus(reserva.id, "RECUSADA");
                    });

                    acoes.append(aprovar, recusar);
                } else {
                    acoes.textContent = "-";
                }

                linha.append(
                    cliente, espaco, periodo,
                    finalidade, status, acoes
                );

                tabelaHtml.appendChild(linha);
            });

            tabela.appendChild(tabelaHtml);

        } catch (erro) {
            mensagem.textContent = erro.message;
        }
    }


    // Envia a alteração do status para a API.
    async function alterarStatus(id, novoStatus) {
        try {
            await chamarApi("/api/reservas/" + id + "/status", {
                method: "PATCH",
                body: JSON.stringify({ status: novoStatus })
            });

            mensagem.textContent = "Reserva atualizada.";
            await carregarReservas();

        } catch (erro) {
            mensagem.textContent = erro.message;
        }
    }


    // Cadastra um novo espaço.
    formulario.addEventListener("submit", async function (evento) {
        evento.preventDefault();

        const dados = Object.fromEntries(new FormData(formulario));

        try {
            await chamarApi("/api/espacos", {
                method: "POST",
                body: JSON.stringify(dados)
            });

            mensagem.textContent = "Espaço cadastrado com sucesso.";
            formulario.reset();

        } catch (erro) {
            mensagem.textContent = erro.message;
        }
    });


    botaoAtualizar.addEventListener("click", carregarReservas);

    document.addEventListener("sessaoAlterada", function () {
        carregarReservas();
        atualizarPermissoes();
    });

    atualizarPermissoes();
    carregarReservas();
});
