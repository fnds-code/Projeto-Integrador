-- 1. Espaços disponíveis.
SELECT nome, tipo, capacidade, valor_hora
FROM espacos WHERE ativo = 1;

-- 2. Reservas aprovadas por espaço.
SELECT espacos.nome, COUNT(reservas.id) AS total_reservas
FROM espacos LEFT JOIN reservas
ON reservas.espaco_id = espacos.id AND reservas.status = 'APROVADA'
GROUP BY espacos.id;

-- 3. Total de vendas por pedido.
SELECT pedidos.id, usuarios.nome AS cliente, pedidos.total, pedidos.status
FROM pedidos JOIN usuarios ON usuarios.id = pedidos.usuario_id;

-- 4. Quantidade atual de cada ingrediente.
SELECT nome, quantidade FROM estoque;

-- 5. Quantidade de pedidos por status.
SELECT status, COUNT(*) AS quantidade
FROM pedidos GROUP BY status;
