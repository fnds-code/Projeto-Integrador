document.addEventListener("DOMContentLoaded", async () => {
    const lista = document.querySelector("#lista-pratos");
    const mensagem = document.querySelector("#mensagem-cardapio");
    const formulario = document.querySelector("#form-prato");
    const seletorEspaco = document.querySelector("#espaco-prato");
    const areaAdmin = document.querySelector("#area-admin-cardapio");

    let sessaoAtual = null;

    async function carregar() {
        try {
            const [pratos, sessao, espacos] = await Promise.all([
                chamarApi("/api/cardapio"),
                chamarApi("/api/auth/sessao"),
                chamarApi("/api/espacos")
            ]);

            sessaoAtual = sessao;
            const podeGerenciar = sessao &&
                ["ADMIN", "EMPRESA", "COZINHEIRO"].includes(sessao.papel);

            areaAdmin.hidden = !podeGerenciar;
            seletorEspaco.innerHTML = '<option value="">Selecione</option>';
            espacos.forEach(espaco => seletorEspaco.add(new Option(espaco.nome, espaco.id)));
            lista.innerHTML = "";

            if (pratos.length === 0) {
                lista.textContent = "Nenhum prato cadastrado.";
                return;
            }

            pratos.forEach(dados => {
                const prato = new Prato(dados);
                const cartao = document.createElement("article");
                cartao.className = "cartao";

                const titulo = document.createElement("h3");
                titulo.textContent = prato.nome;

                const descricao = document.createElement("p");
                descricao.textContent = prato.descricao || "";

                const preco = document.createElement("strong");
                preco.textContent = `R$ ${prato.preco.toFixed(2).replace(".", ",")}`;

                cartao.append(titulo, descricao, preco);

                if (dados.ativo === 0) {
                    const indisponivel = document.createElement("p");
                    indisponivel.textContent = "Indisponível no cardápio";
                    cartao.appendChild(indisponivel);
                }

                if (sessao && sessao.papel === "CLIENTE" && dados.ativo === 1) {
                    const link = document.createElement("a");
                    link.href = "/pedidos";
                    link.className = "botao";
                    link.textContent = "Ir para o carrinho";
                    cartao.appendChild(link);
                }

                if (podeGerenciar && dados.ativo === 1) {
                    const remover = document.createElement("button");
                    remover.type = "button";
                    remover.className = "botao-secundario";
                    remover.textContent = "Remover do cardápio";
                    remover.addEventListener("click", async () => {
                        try {
                            await chamarApi(`/api/cardapio/${prato.id}`, { method: "DELETE" });
                            mensagem.textContent = "Prato removido da disponibilidade.";
                            await carregar();
                        } catch (erro) {
                            mensagem.textContent = erro.message;
                        }
                    });
                    cartao.appendChild(remover);
                }

                lista.appendChild(cartao);
            });
        } catch (erro) {
            mensagem.textContent = erro.message;
        }
    }

    formulario.addEventListener("submit", async evento => {
        evento.preventDefault();

        if (!sessaoAtual || !["ADMIN", "EMPRESA", "COZINHEIRO"].includes(sessaoAtual.papel)) {
            mensagem.textContent = "Entre com uma conta autorizada para gerenciar o cardápio.";
            return;
        }

        const dados = Object.fromEntries(new FormData(formulario));
        try {
            await chamarApi("/api/cardapio", {
                method: "POST",
                body: JSON.stringify(dados)
            });
            mensagem.textContent = "Prato adicionado ao cardápio.";
            formulario.reset();
            await carregar();
        } catch (erro) {
            mensagem.textContent = erro.message;
        }
    });

    document.addEventListener("sessaoAlterada", carregar);
    await carregar();
});
