# Sabor & Clic

Sistema académico simples para uma empresa que administra espaços gastronómicos e dark kitchens.

## Como executar

1. Instale Python 3.
2. No terminal, entre na pasta do projeto.
3. Crie o ambiente virtual:

   `python3 -m venv .venv`

4. Ative o ambiente virtual no Linux:

   `source .venv/bin/activate`

   No Windows, use:

   `.venv\Scripts\activate`

5. Instale as dependências:

   `pip install -r requirements.txt`

6. Execute o projeto:

   `python run.py`

7. Abra `http://127.0.0.1:5000` no navegador.

## Contas de demonstração

| Perfil | E-mail | Senha |
|---|---|---|
| Administrador | admin@saborclic.local | Demo123! |
| Cliente | cliente@saborclic.local | Demo123! |
| Cozinheiro | cozinha@saborclic.local | Demo123! |

## Páginas

- Espaços e reservas: consulta e solicitação de horários.
- Cardápio: consulta de pratos; administrador cadastra e desativa pratos.
- Pedidos: cliente monta o carrinho, informa o endereço de entrega e acompanha o pedido.
- Cozinha: cozinheiro consulta a fila, visualiza o endereço de entrega, informa tempo e atualiza o status.
- Painel: administrador acompanha e aprova reservas.

## Tipos de conta

No cadastro, o utilizador pode escolher um dos três perfis:

- **Cliente:** consulta o cardápio, realiza pedidos e solicita reservas.
- **Cozinheiro:** acessa a fila da cozinha, atualiza o andamento dos pedidos e pode adicionar/inativar pratos no cardápio.
- **Empresa / Administrador:** gerencia espaços, cardápio completo e acompanha as reservas.