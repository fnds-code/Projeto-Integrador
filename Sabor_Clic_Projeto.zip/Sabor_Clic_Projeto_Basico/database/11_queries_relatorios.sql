
SELECT nome, tipo, capacidade, valor_hora
FROM espacos WHERE ativo = 1;


SELECT espacos.nome, COUNT(reservas.id) AS total_reservas
FROM espacos LEFT JOIN reservas
ON reservas.espaco_id = espacos.id AND reservas.status = 'APROVADA'
GROUP BY espacos.id;

SELECT pedidos.id, usuarios.nome AS cliente, pedidos.total, pedidos.status
FROM pedidos JOIN usuarios ON usuarios.id = pedidos.usuario_id;

SELECT nome, quantidade FROM estoque;


SELECT status, COUNT(*) AS quantidade
FROM pedidos GROUP BY status;
