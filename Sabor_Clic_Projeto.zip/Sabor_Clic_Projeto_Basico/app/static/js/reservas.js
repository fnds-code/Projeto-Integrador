document.addEventListener("DOMContentLoaded", async function () {
    const seletor = document.querySelector("#espaco-reserva");
    const formulario = document.querySelector("#form-reserva");
    const mensagem = document.querySelector("#mensagem-reserva");


    try {
        const espacos = await chamarApi("/api/espacos");

        espacos.forEach(function (espaco) {
            const opcao = new Option(espaco.nome, espaco.id);
            seletor.add(opcao);
        });


        const parametros = new URLSearchParams(window.location.search);
        const idEspaco = parametros.get("espaco");

        if (idEspaco) {
            seletor.value = idEspaco;
        }

        if (espacos.length === 0) {
            mensagem.textContent = "Não há espaços disponíveis para reserva.";
        }

    } catch (erro) {
        mensagem.textContent = "Não foi possível carregar os espaços. Atualize a página. " + erro.message;
    }

    
    formulario.addEventListener("submit", async function (evento) {
        evento.preventDefault();
        mensagem.textContent = "";

        const dados = Object.fromEntries(new FormData(formulario));

        if (!dados.espaco_id) {
            mensagem.textContent = "Selecione um espaço antes de continuar.";
            seletor.focus();
            return;
        }

        if (!dados.data_inicio) {
            mensagem.textContent = "Informe a data e o horário de início.";
            formulario.elements.data_inicio.focus();
            return;
        }

        if (!dados.data_fim) {
            mensagem.textContent = "Informe a data e o horário de término.";
            formulario.elements.data_fim.focus();
            return;
        }

        if (!dados.finalidade.trim()) {
            mensagem.textContent = "Explique brevemente a finalidade da reserva.";
            formulario.elements.finalidade.focus();
            return;
        }

        if (new Date(dados.data_fim) <= new Date(dados.data_inicio)) {
            mensagem.textContent = "O término deve ser depois do início da reserva.";
            formulario.elements.data_fim.focus();
            return;
        }

        try {
            const reserva = await chamarApi("/api/reservas", {
                method: "POST",
                body: JSON.stringify(dados)
            });

            mensagem.textContent =
                "Solicitação enviada! Número: " + reserva.id +
                ". Status: " + reserva.status + ".";

            formulario.reset();

        } catch (erro) {
            mensagem.textContent = erro.message;
        }
    });
});
