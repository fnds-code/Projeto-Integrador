
function mostrarMensagem(texto) {
    const area = document.querySelector("#mensagem-global");
    if (area) {
        area.textContent = texto;
        area.hidden = false;
    }
}


async function chamarApi(url, opcoes = {}) {
    const resposta = await fetch(url, {
        ...opcoes,
        headers: {
            "Content-Type": "application/json",
            ...opcoes.headers
        }
    });

    const texto = await resposta.text();
    let resultado;

    try {
        resultado = JSON.parse(texto);
    } catch (erro) {
        console.error("Resposta inesperada do servidor:", texto);
        throw new Error(`O servidor retornou uma resposta inválida (HTTP ${resposta.status}).`);
    }

    if (!resposta.ok || resultado.sucesso === false) {
        throw new Error(resultado.erro || "Ocorreu um erro.");
    }

    return resultado.dados;
}


document.addEventListener("DOMContentLoaded", function () {
    const janela = document.querySelector("#janela-login");
    const botaoAbrir = document.querySelector("#abrir-login");
    const botaoFechar = document.querySelector("#fechar-login");
    const formularioLogin = document.querySelector("#form-login");
    const formularioCadastro = document.querySelector("#form-cadastro");

    function atualizarAcesso(usuario) {
        if (usuario) {
            botaoAbrir.textContent = "Sair (" + usuario.nome + ")";
        } else {
            botaoAbrir.textContent = "Entrar";
        }

        document.dispatchEvent(new CustomEvent("sessaoAlterada", {
            detail: usuario
        }));
    }

    async function consultarSessao() {
        try {
            const usuario = await chamarApi("/api/auth/sessao");
            atualizarAcesso(usuario);
        } catch (erro) {
            atualizarAcesso(null);
        }
    }

    botaoAbrir.addEventListener("click", async function () {
        const usuario = await chamarApi("/api/auth/sessao").catch(() => null);

        if (usuario) {
            try {
                await chamarApi("/api/auth/logout", { method: "POST" });
                atualizarAcesso(null);
                mostrarMensagem("Você saiu da plataforma.");
                if (janela.open) janela.close();
            } catch (erro) {
                mostrarMensagem(erro.message);
            }
            return;
        }

        formularioLogin.hidden = false;
        formularioCadastro.hidden = true;
        janela.showModal();
    });

    botaoFechar.addEventListener("click", function () {
        janela.close();
    });

    document.querySelector("#mostrar-cadastro").addEventListener("click", function () {
        formularioLogin.hidden = true;
        formularioCadastro.hidden = false;
    });

    document.querySelector("#mostrar-login").addEventListener("click", function () {
        formularioCadastro.hidden = true;
        formularioLogin.hidden = false;
    });

    formularioLogin.addEventListener("submit", async function (evento) {
        evento.preventDefault();
        
  
        const dados = Object.fromEntries(new FormData(formularioLogin));

        try {
            const usuario = await chamarApi("/api/auth/login", {
                method: "POST",
                body: JSON.stringify(dados)
            });
            document.querySelector("#mensagem-login").textContent = "Login realizado com sucesso.";
            mostrarMensagem("Login realizado com sucesso.");
            janela.close();
            atualizarAcesso(usuario);
            formularioLogin.reset();
        } catch (erro) {
            document.querySelector("#mensagem-login").textContent = erro.message;
        }
    });

    formularioCadastro.addEventListener("submit", async function (evento) {
        evento.preventDefault();
        

        const dados = Object.fromEntries(new FormData(formularioCadastro));
        dados.tamanho_senha = dados.senha.length;

        try {
            await chamarApi("/api/auth/cadastro", {
                method: "POST",
                body: JSON.stringify(dados)
            });
            const usuario = await chamarApi("/api/auth/sessao");
            document.querySelector("#mensagem-cadastro").textContent = "Conta criada com sucesso.";
            mostrarMensagem("Conta criada com sucesso.");
            janela.close();
            atualizarAcesso(usuario);
            formularioCadastro.reset();
        } catch (erro) {
            document.querySelector("#mensagem-cadastro").textContent = erro.message;
        }
    });

    consultarSessao();
});