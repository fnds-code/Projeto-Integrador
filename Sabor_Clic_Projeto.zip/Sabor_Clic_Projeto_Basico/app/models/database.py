import os
import sqlite3


def conectar(caminho):
    banco = sqlite3.connect(caminho)
    banco.row_factory = sqlite3.Row
    banco.execute("PRAGMA foreign_keys = ON")
    return banco


def inicializar_banco(caminho):
    pasta = os.path.dirname(os.path.abspath(caminho))
    os.makedirs(pasta, exist_ok=True)
    pasta_sql = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "database"))
    banco = conectar(caminho)

    for nome in ("01_modelo_fisico.sql", "02_insercoes_basicas.sql", "20_triggers.sql"):
        with open(os.path.join(pasta_sql, nome), encoding="utf-8") as arquivo:
            banco.executescript(arquivo.read())

    banco.commit()
    banco.close()