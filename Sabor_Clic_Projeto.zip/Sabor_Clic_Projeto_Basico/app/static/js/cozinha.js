document.addEventListener("DOMContentLoaded", () => {
    const fila = document.querySelector("#fila-pedidos");
    const mensagem = document.querySelector("#mensagem-cozinha");

    async function carregarFila() {
        try {
            const pedidos = await chamarApi("/api/cozinha/pedidos");
            fila.innerHTML = "";
            if (pedidos.length === 0) {
                fila.textContent = "Não há pedidos pendentes.";
                return;
            }
            pedidos.forEach(pedido => {
                const cartao = document.createElement("article");
                cartao.className = "cartao";
                
                const titulo = document.createElement("h3");
                titulo.textContent = `Pedido #${pedido.id} — ${pedido.nome_cliente}`;
                
                const itens = document.createElement("p");
                itens.textContent = pedido.itens.map(item => `${item.nome} (${item.quantidade})`).join(", ");
                
                const endereco = document.createElement("p");
                endereco.textContent = `Endereço: ${pedido.endereco_entrega || "Não informado"}`;
                
                const status = document.createElement("p");
                status.textContent = `Status: ${PedidoStatus(pedido.status)}`;
                
                const tempo = document.createElement("input");
                tempo.type = "number";
                tempo.min = "0";
                tempo.placeholder = "Tempo estimado (minutos)";
                
                const iniciar = document.createElement("button");
                iniciar.textContent = "Iniciar preparo";
                iniciar.disabled = pedido.status === "EM_PREPARO";
                iniciar.addEventListener("click", () => atualizar(pedido.id, "EM_PREPARO", tempo.value));
                
                const pronto = document.createElement("button");
                pronto.textContent = "Pronto para entrega";
                pronto.addEventListener("click", () => atualizar(pedido.id, "PRONTO", tempo.value || pedido.tempo_estimado || 0));
                
                cartao.append(titulo, itens, endereco, status, tempo, iniciar, pronto);
                fila.appendChild(cartao);
            });
        } catch (erro) { 
            mensagem.textContent = erro.message; 
        }
    }

    function PedidoStatus(status) {
        if (status === "EM_PREPARO") return "Em preparo";
        if (status === "PRONTO") return "Pronto para entrega";
        return "Aguardando";
    }

    async function atualizar(id, status, minutos) {
        try {
            await chamarApi(`/api/cozinha/pedidos/${id}`, {
                method: "PATCH",
                body: JSON.stringify({ status, tempo_estimado: minutos || 0 })
            });
            mensagem.textContent = "Pedido atualizado.";
            // CORREÇÃO: Apenas recarrega a fila. Não adiciona novos 'Event Listeners' aqui.
            await carregarFila();
        } catch (erro) { 
            mensagem.textContent = erro.message; 
        }
    }

    document.querySelector("#atualizar-fila").addEventListener("click", carregarFila);
    carregarFila();
});