document.addEventListener("DOMContentLoaded", async () => {
    const carrinho = new Carrinho();
    const areaCarrinho = document.querySelector("#carrinho");
    const total = document.querySelector("#total-carrinho");
    const mensagem = document.querySelector("#mensagem-pedidos");
    const historico = document.querySelector("#historico-pedidos");

    function mostrarCarrinho() {
        areaCarrinho.innerHTML = "";
        carrinho.listar().forEach(item => {
            const linha = document.createElement("p");
            linha.textContent = `${item.prato.nome} — ${item.quantidade} unidade(s)`;
            areaCarrinho.appendChild(linha);
        });
        total.textContent = `Total: R$ ${carrinho.total().toFixed(2).replace(".", ",")}`;
    }

    async function carregarCardapio() {
        try {
            const pratos = await chamarApi("/api/cardapio");
            const titulo = document.createElement("h2");
            titulo.textContent = "Adicionar pratos";
            areaCarrinho.before(titulo);
            const lista = document.createElement("div");
            lista.className = "cartoes";
            pratos.forEach(dados => {
                const prato = new Prato(dados);
                const cartao = document.createElement("article");
                cartao.className = "cartao";
                const nome = document.createElement("h3");
                nome.textContent = prato.nome;
                const preco = document.createElement("p");
                preco.textContent = `R$ ${prato.preco.toFixed(2).replace(".", ",")}`;
                const botao = document.createElement("button");
                botao.textContent = "Adicionar";
                botao.addEventListener("click", () => {
                    carrinho.adicionar(prato);
                    mostrarCarrinho();
                });
                cartao.append(nome, preco, botao);
                lista.appendChild(cartao);
            });
            areaCarrinho.before(lista);
        } catch (erro) {
            mensagem.textContent = erro.message;
        }
    }

    async function carregarHistorico() {
        try {
            const pedidos = await chamarApi("/api/pedidos");
            historico.innerHTML = "";
            if (pedidos.length === 0) {
                historico.textContent = "Você ainda não fez pedidos.";
                return;
            }
            pedidos.forEach(pedido => {
                const bloco = document.createElement("article");
                bloco.className = "cartao";
                const itens = pedido.itens.map(item => `${item.nome} (${item.quantidade})`).join(", ");
                bloco.textContent = `Pedido #${pedido.id}: ${itens} — R$ ${Number(pedido.total).toFixed(2)} — ${Pedido.formatarStatus(pedido.status)} — Entrega: ${pedido.endereco_entrega}`;
                historico.appendChild(bloco);
            });
        } catch (erro) {
            historico.textContent = erro.message;
        }
    }

    document.querySelector("#finalizar-pedido").addEventListener("click", async () => {
        const itens = carrinho.listar().map(item => ({ id: item.prato.id, quantidade: item.quantidade }));
        if (itens.length === 0) {
            mensagem.textContent = "Seu carrinho está vazio.";
            return;
        }
        const endereco = document.querySelector("#endereco-entrega").value.trim();
        if (!endereco) {
            mensagem.textContent = "Informe o endereço de entrega.";
            return;
        }

        try {
            const pedido = await chamarApi("/api/pedidos", {
                method: "POST",
                body: JSON.stringify({ itens, endereco_entrega: endereco })
            });
            mensagem.textContent = `Pedido #${pedido.id} enviado. Total: R$ ${pedido.total.toFixed(2)}.`;
            carrinho.limpar();
            document.querySelector("#endereco-entrega").value = "";
            mostrarCarrinho();
            carregarHistorico();
        } catch (erro) {
            mensagem.textContent = erro.message;
        }
    });

    document.querySelector("#atualizar-pedidos").addEventListener("click", carregarHistorico);
    
    document.addEventListener("sessaoAlterada", async function () {
        await carregarHistorico();
    });

    await carregarCardapio();
    mostrarCarrinho();
    carregarHistorico();
});