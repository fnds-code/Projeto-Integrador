CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    senha_criptografada TEXT NOT NULL,
    papel TEXT NOT NULL,
    turno TEXT DEFAULT '',
    especialidade TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS espacos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    tipo TEXT NOT NULL,
    descricao TEXT NOT NULL,
    capacidade INTEGER NOT NULL,
    valor_hora REAL NOT NULL,
    endereco TEXT NOT NULL,
    equipamentos TEXT DEFAULT '',
    ativo INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS reservas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    espaco_id INTEGER NOT NULL,
    usuario_id INTEGER NOT NULL,
    data_inicio TEXT NOT NULL,
    data_fim TEXT NOT NULL,
    finalidade TEXT NOT NULL,
    status TEXT DEFAULT 'PENDENTE',
    criado_em TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (espaco_id) REFERENCES espacos(id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

CREATE TABLE IF NOT EXISTS itens_cardapio (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    espaco_id INTEGER NOT NULL,
    nome TEXT NOT NULL,
    descricao TEXT,
    preco REAL NOT NULL,
    ativo INTEGER DEFAULT 1,
    FOREIGN KEY (espaco_id) REFERENCES espacos(id)
);

CREATE TABLE IF NOT EXISTS pedidos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario_id INTEGER NOT NULL,
    total REAL DEFAULT 0,
    status TEXT DEFAULT 'AGUARDANDO',
    tempo_estimado INTEGER DEFAULT 0,
    endereco_entrega TEXT DEFAULT '',
    criado_em TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

CREATE TABLE IF NOT EXISTS pedido_itens (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pedido_id INTEGER NOT NULL,
    item_id INTEGER NOT NULL,
    quantidade INTEGER NOT NULL,
    FOREIGN KEY (pedido_id) REFERENCES pedidos(id),
    FOREIGN KEY (item_id) REFERENCES itens_cardapio(id)
);

CREATE TABLE IF NOT EXISTS estoque (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT UNIQUE NOT NULL,
    quantidade INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS item_estoque (
    item_id INTEGER NOT NULL,
    estoque_id INTEGER NOT NULL,
    quantidade_por_item INTEGER NOT NULL,
    PRIMARY KEY (item_id, estoque_id),
    FOREIGN KEY (item_id) REFERENCES itens_cardapio(id),
    FOREIGN KEY (estoque_id) REFERENCES estoque(id)
);

