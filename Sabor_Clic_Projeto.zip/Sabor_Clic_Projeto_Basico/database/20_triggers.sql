
CREATE TRIGGER IF NOT EXISTS baixar_estoque_pedido
AFTER INSERT ON pedido_itens
BEGIN
    UPDATE estoque
    SET quantidade = quantidade - (
        NEW.quantidade * (
            SELECT quantidade_por_item
            FROM item_estoque
            WHERE item_id = NEW.item_id AND estoque_id = estoque.id
        )
    )
    WHERE id IN (
        SELECT estoque_id FROM item_estoque WHERE item_id = NEW.item_id
    );
END;


CREATE TRIGGER IF NOT EXISTS impedir_reserva_sobreposta
BEFORE UPDATE OF status ON reservas
WHEN NEW.status = 'APROVADA'
BEGIN
    SELECT CASE WHEN EXISTS (
        SELECT 1 FROM reservas
        WHERE espaco_id = NEW.espaco_id
          AND id <> NEW.id
          AND status = 'APROVADA'
          AND NEW.data_inicio < data_fim
          AND NEW.data_fim > data_inicio
    ) THEN RAISE(ABORT, 'conflito_reserva') END;
END;
