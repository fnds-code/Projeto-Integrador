// Classe principal: guarda o identificador das entidades do sistema.
class Entidade {
    #id;

    constructor(id) {
        this.#id = id;
    }

    get id() { return this.#id; }
}

// Prato herda o identificador da classe Entidade.
class Prato extends Entidade {
    #nome;
    #descricao;
    #preco;
    #ativo;

    constructor(dados) {
        super(dados.id);
        this.#nome = dados.nome;
        this.#descricao = dados.descricao;
        this.#preco = Number(dados.preco);
        this.#ativo = dados.ativo;
    }

    get nome() { return this.#nome; }
    get descricao() { return this.#descricao; }
    get preco() { return this.#preco; }
    get ativo() { return this.#ativo; }
}

class ItemPedido {
    #prato;
    #quantidade;

    constructor(prato, quantidade = 1) {
        this.#prato = prato;
        this.#quantidade = quantidade;
    }

    get prato() { return this.#prato; }
    get quantidade() { return this.#quantidade; }

    aumentar() {
        this.#quantidade++;
    }

    get subtotal() {
        return this.#prato.preco * this.#quantidade;
    }
}

class Carrinho {
    #itens = [];

    adicionar(prato) {
        const existente = this.#itens.find(item => item.prato.id === prato.id);
        if (existente) {
            existente.aumentar();
        } else {
            this.#itens.push(new ItemPedido(prato));
        }
    }

    listar() {
        return [...this.#itens];
    }

    total() {
        return this.#itens.reduce((soma, item) => soma + item.subtotal, 0);
    }

    limpar() {
        this.#itens = [];
    }
}

// Pedido também herda o identificador da classe Entidade.
class Pedido extends Entidade {
    #status;

    constructor(dados = {}) {
        super(dados.id || null);
        this.#status = dados.status || "AGUARDANDO";
    }

    get status() { return this.#status; }

    static formatarStatus(status) {
        const nomes = {
            AGUARDANDO: "Aguardando",
            EM_PREPARO: "Em preparo",
            PRONTO: "Pronto para entrega"
        };
        return nomes[status] || status;
    }
}
