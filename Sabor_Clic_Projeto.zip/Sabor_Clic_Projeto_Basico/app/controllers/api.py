from datetime import datetime
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
from flask import Blueprint, request, session, current_app, jsonify, flash
from app.models.database import conectar

api = Blueprint("api", __name__, url_prefix="/api")

def resposta_ok(dados, status=200):
    return jsonify({"sucesso": True, "dados": dados}), status

def resposta_erro(mensagem, status=400):
    return jsonify({"sucesso": False, "erro": mensagem}), status

def abrir_banco():
    return conectar(current_app.config["BANCO"])

@api.before_request
def verificar_permissao():
    """Confere o login e o perfil antes de executar rotas protegidas."""
    caminho = request.path
    metodo = request.method
    usuario = session.get("usuario")


    if caminho.startswith("/api/auth/") or caminho == "/api/":
        return


    if metodo == "GET" and caminho in ("/api/espacos", "/api/cardapio"):
        return


    if usuario is None:
        return resposta_erro("Faça login para continuar.", 401)

    papel = usuario["papel"]


    aprovar_reserva = caminho.startswith("/api/reservas/") and caminho.endswith("/status") and metodo == "PATCH"
    alterar_espacos = caminho.startswith("/api/espacos") and metodo in ("POST", "PUT", "DELETE")
    
    if aprovar_reserva or alterar_espacos:
        if papel not in ("ADMIN", "EMPRESA"):
            return resposta_erro("Acesso restrito à gestão da empresa.", 403)


    alterar_cardapio = caminho.startswith("/api/cardapio") and metodo in ("POST", "PUT", "DELETE")
    if alterar_cardapio:
        if papel not in ("ADMIN", "EMPRESA", "COZINHEIRO"):
            return resposta_erro("Apenas a equipe pode alterar o cardápio.", 403)


    if caminho.startswith("/api/cozinha"):
        if papel not in ("ADMIN", "COZINHEIRO"):
            return resposta_erro("Acesso exclusivo da equipe da cozinha.", 403)


    if caminho == "/api/pedidos" and metodo == "POST":
        if papel != "CLIENTE":
            return resposta_erro("Entre como cliente para fazer um pedido.", 403)


@api.get("/")
def verificar_api():
    return resposta_ok({
        "projeto": "Sabor & Clic",
        "mensagem": "API funcionando"
    })


@api.post("/auth/login")
def login():
    dados = request.get_json(silent=True) or {}
    email = dados.get("email", "").strip().lower()
    senha = dados.get("senha", "")

    banco = abrir_banco()
    usuario = banco.execute(
        "SELECT * FROM usuarios WHERE email = ?",
        (email,)
    ).fetchone()
    banco.close()

    if usuario is None:
        flash("E-mail ou senha inválidos.", "erro")
        return resposta_erro("E-mail ou senha inválidos.", 401)

    if not check_password_hash(usuario["senha_criptografada"], senha):
        flash("E-mail ou senha inválidos.", "erro")
        return resposta_erro("E-mail ou senha inválidos.", 401)

    session["usuario"] = {
        "id": usuario["id"],
        "nome": usuario["nome"],
        "papel": usuario["papel"]
    }

    flash("Login realizado com sucesso.", "sucesso")
    return resposta_ok(session["usuario"])


@api.post("/auth/cadastro")
def cadastrar_conta():
    dados = request.get_json(silent=True) or {}
    nome = dados.get("nome", "").strip()
    email = dados.get("email", "").strip().lower()
    senha = dados.get("senha", "")
    papel = dados.get("papel", "CLIENTE").upper()

    if not nome or not email or not senha:
        return resposta_erro("Preencha todos os campos.")

    papeis_permitidos = ("CLIENTE", "COZINHEIRO", "EMPRESA")
    if papel not in papeis_permitidos:
        return resposta_erro("Selecione um tipo de conta válido.")

    if "@" not in email or "." not in email.split("@")[-1]:
        return resposta_erro("Informe um e-mail válido.")

    if len(senha) < 8:
        return resposta_erro("A senha deve ter pelo menos 8 caracteres.")

    senha_hash = generate_password_hash(senha)
    
    banco = abrir_banco()
    try:
        cursor = banco.execute(
            "INSERT INTO usuarios (nome, email, senha_criptografada, papel) VALUES (?, ?, ?, ?)",
            (nome, email, senha_hash, papel)
        )
        banco.commit()

        session["usuario"] = {
            "id": cursor.lastrowid,
            "nome": nome,
            "papel": papel
        }
        flash("Conta criada com sucesso.", "sucesso")
        banco.close()
        return resposta_ok({"mensagem": "Conta criada com sucesso."}, 201)

    except sqlite3.IntegrityError:
        banco.close()
        return resposta_erro("Este e-mail já está cadastrado.", 409)


@api.post("/auth/logout")
def logout():
    session.clear()
    return resposta_ok({"mensagem": "Você saiu da plataforma."})


@api.get("/auth/sessao")
def consultar_sessao():
    return resposta_ok(session.get("usuario"))



@api.get("/espacos")
def listar_espacos():
    banco = abrir_banco()
    espacos = banco.execute("SELECT * FROM espacos WHERE ativo = 1 ORDER BY id").fetchall()
    banco.close()
    return resposta_ok([dict(espaco) for espaco in espacos])

@api.post("/espacos")
def cadastrar_espaco():
    dados = request.get_json(silent=True) or {}
    campos = ["nome", "tipo", "descricao", "capacidade", "valor_hora", "endereco"]

    for campo in campos:
        if dados.get(campo) in (None, ""):
            return resposta_erro("Preencha todos os campos obrigatórios.")

    try:
        capacidade = int(dados["capacidade"])
        valor_hora = float(dados["valor_hora"])
        if capacidade <= 0 or valor_hora < 0:
            return resposta_erro("Capacidade ou valor inválido.")
    except (ValueError, TypeError):
        return resposta_erro("Capacidade ou valor inválido.")

    if dados["tipo"] not in ["DARK_KITCHEN", "BANCADA", "COZINHA_COMPARTILHADA"]:
        return resposta_erro("Tipo de espaço inválido.")

    banco = abrir_banco()
    cursor = banco.execute(
        "INSERT INTO espacos (nome, tipo, descricao, capacidade, valor_hora, endereco, equipamentos) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (dados["nome"], dados["tipo"], dados["descricao"], capacidade, valor_hora, dados["endereco"], dados.get("equipamentos", ""))
    )
    banco.commit()
    novo_id = cursor.lastrowid
    banco.close()
    return resposta_ok({"id": novo_id}, 201)

@api.put("/espacos/<int:espaco_id>")
def editar_espaco(espaco_id):
    dados = request.get_json(silent=True) or {}
    try:
        capacidade = int(dados["capacidade"])
        valor_hora = float(dados["valor_hora"])
    except (ValueError, TypeError, KeyError):
        return resposta_erro("Capacidade ou valor inválido.")

    banco = abrir_banco()
    cursor = banco.execute(
        "UPDATE espacos SET nome = ?, tipo = ?, descricao = ?, capacidade = ?, valor_hora = ?, endereco = ?, equipamentos = ? WHERE id = ? AND ativo = 1",
        (dados["nome"], dados["tipo"], dados["descricao"], capacidade, valor_hora, dados["endereco"], dados.get("equipamentos", ""), espaco_id)
    )
    banco.commit()
    alterados = cursor.rowcount
    banco.close()

    if alterados == 0:
        return resposta_erro("Espaço não encontrado.", 404)
    return resposta_ok({"mensagem": "Espaço atualizado."})

@api.delete("/espacos/<int:espaco_id>")
def desativar_espaco(espaco_id):
    banco = abrir_banco()
    cursor = banco.execute("UPDATE espacos SET ativo = 0 WHERE id = ?", (espaco_id,))
    banco.commit()
    banco.close()
    if cursor.rowcount == 0:
        return resposta_erro("Espaço não encontrado.", 404)
    return resposta_ok({"mensagem": "Espaço desativado."})


@api.get("/reservas")
def listar_reservas():
    usuario = session.get("usuario")
    banco = abrir_banco()
    consulta = "SELECT reservas.*, espacos.nome AS nome_espaco, usuarios.nome AS nome_cliente FROM reservas JOIN espacos ON espacos.id = reservas.espaco_id JOIN usuarios ON usuarios.id = reservas.usuario_id"
    parametros = ()

    if usuario["papel"] not in ("ADMIN", "EMPRESA"):
        consulta += " WHERE reservas.usuario_id = ?"
        parametros = (usuario["id"],)

    consulta += " ORDER BY reservas.id DESC"
    reservas = banco.execute(consulta, parametros).fetchall()
    banco.close()
    return resposta_ok([dict(reserva) for reserva in reservas])

@api.post("/reservas")
def solicitar_reserva():
    usuario = session.get("usuario")
    dados = request.get_json(silent=True) or {}
    try:
        inicio = datetime.fromisoformat(dados["data_inicio"])
        fim = datetime.fromisoformat(dados["data_fim"])
        espaco_id = int(dados["espaco_id"])
        if fim <= inicio:
            return resposta_erro("A data final deve ser posterior à data inicial.")
    except (ValueError, TypeError, KeyError):
        return resposta_erro("Data ou espaço inválido.")

    banco = abrir_banco()
    espaco = banco.execute("SELECT id FROM espacos WHERE id = ? AND ativo = 1", (espaco_id,)).fetchone()
    
    if espaco is None:
        banco.close()
        return resposta_erro("Espaço não encontrado.", 404)

    cursor = banco.execute(
        "INSERT INTO reservas (espaco_id, usuario_id, data_inicio, data_fim, finalidade) VALUES (?, ?, ?, ?, ?)",
        (espaco_id, usuario["id"], dados["data_inicio"], dados["data_fim"], dados["finalidade"])
    )
    banco.commit()
    reserva_id = cursor.lastrowid
    banco.close()
    return resposta_ok({"id": reserva_id, "status": "PENDENTE"}, 201)

@api.patch("/reservas/<int:reserva_id>/status")
def atualizar_status_reserva(reserva_id):
    dados = request.get_json(silent=True) or {}
    novo_status = dados.get("status")
    
    if novo_status not in ["APROVADA", "RECUSADA", "CANCELADA"]:
        return resposta_erro("Status informado não é válido.")

    banco = abrir_banco()
    try:
        cursor = banco.execute("UPDATE reservas SET status = ? WHERE id = ?", (novo_status, reserva_id))
        banco.commit()
        if cursor.rowcount == 0:
            return resposta_erro("Reserva não encontrada.", 404)
        return resposta_ok({"mensagem": "Status atualizado."})
    except sqlite3.IntegrityError:
        banco.rollback()
        return resposta_erro("Já existe uma reserva aprovada nesse horário.", 409)
    finally:
        banco.close()


@api.get("/cardapio")
def listar_cardapio():
    usuario = session.get("usuario")
    banco = abrir_banco()
    if usuario and usuario["papel"] in ("ADMIN", "EMPRESA", "COZINHEIRO"):
        itens = banco.execute("SELECT * FROM itens_cardapio ORDER BY nome").fetchall()
    else:
        itens = banco.execute("SELECT * FROM itens_cardapio WHERE ativo = 1 ORDER BY nome").fetchall()
    banco.close()
    return resposta_ok([dict(item) for item in itens])

@api.post("/cardapio")
def cadastrar_prato():
    dados = request.get_json(silent=True) or {}
    nome = dados.get("nome", "").strip()
    try:
        preco = float(dados.get("preco", 0))
        espaco_id = int(dados.get("espaco_id", 0))
        if not nome or preco <= 0 or espaco_id <= 0: raise ValueError
    except (ValueError, TypeError):
        return resposta_erro("Informe nome, espaço e preço válido.")

    banco = abrir_banco()
    if banco.execute("SELECT id FROM espacos WHERE id = ? AND ativo = 1", (espaco_id,)).fetchone() is None:
        banco.close()
        return resposta_erro("Escolha um espaço ativo.")

    cursor = banco.execute("INSERT INTO itens_cardapio (espaco_id, nome, descricao, preco) VALUES (?, ?, ?, ?)",
                           (espaco_id, nome, dados.get("descricao", "").strip(), preco))
    banco.commit()
    novo_id = cursor.lastrowid
    banco.close()
    return resposta_ok({"id": novo_id}, 201)

@api.put("/cardapio/<int:item_id>")
def editar_prato(item_id):
    dados = request.get_json(silent=True) or {}
    try:
        preco = float(dados.get("preco", 0))
    except (ValueError, TypeError):
        return resposta_erro("Preço inválido.")

    banco = abrir_banco()
    cursor = banco.execute("UPDATE itens_cardapio SET nome = ?, descricao = ?, preco = ? WHERE id = ?",
                           (dados.get("nome", "").strip(), dados.get("descricao", "").strip(), preco, item_id))
    banco.commit()
    banco.close()
    if cursor.rowcount == 0:
        return resposta_erro("Prato não encontrado.", 404)
    return resposta_ok({"mensagem": "Prato atualizado."})

@api.delete("/cardapio/<int:item_id>")
def desativar_prato(item_id):
    banco = abrir_banco()
    cursor = banco.execute("UPDATE itens_cardapio SET ativo = 0 WHERE id = ?", (item_id,))
    banco.commit()
    banco.close()
    return resposta_ok({"mensagem": "Prato removido."}) if cursor.rowcount else resposta_erro("Prato não encontrado.", 404)



@api.get("/pedidos")
def listar_pedidos():
    usuario = session.get("usuario")
    banco = abrir_banco()
    consulta = "SELECT pedidos.*, usuarios.nome AS nome_cliente FROM pedidos JOIN usuarios ON usuarios.id = pedidos.usuario_id"
    parametros = ()
    
    if usuario["papel"] == "CLIENTE":
        consulta += " WHERE pedidos.usuario_id = ?"
        parametros = (usuario["id"],)
    consulta += " ORDER BY pedidos.id DESC"
    
    pedidos = [dict(item) for item in banco.execute(consulta, parametros).fetchall()]

    for pedido in pedidos:
        pedido["itens"] = [dict(item) for item in banco.execute(
            "SELECT itens_cardapio.nome, pedido_itens.quantidade FROM pedido_itens JOIN itens_cardapio ON itens_cardapio.id = pedido_itens.item_id WHERE pedido_itens.pedido_id = ?",
            (pedido["id"],)
        ).fetchall()]

    banco.close()
    return resposta_ok(pedidos)

@api.post("/pedidos")
def criar_pedido():
    usuario = session.get("usuario")
    dados = request.get_json(silent=True) or {}
    itens = dados.get("itens", [])
    endereco = dados.get("endereco_entrega", "").strip()

    if not itens or not endereco:
        return resposta_erro("Carrinho vazio ou endereço faltando.")

    banco = abrir_banco()
    total = 0
    itens_validos = []

    try:
        for item in itens:
            item_id = int(item.get("id", 0))
            quantidade = int(item.get("quantidade", 0))
            if quantidade <= 0: raise ValueError

            prato = banco.execute("SELECT id, preco FROM itens_cardapio WHERE id = ? AND ativo = 1", (item_id,)).fetchone()
            if not prato:
                banco.close()
                return resposta_erro("Prato indisponível.", 409)

            total += prato["preco"] * quantidade
            itens_validos.append((item_id, quantidade))

        cursor = banco.execute("INSERT INTO pedidos (usuario_id, total, endereco_entrega) VALUES (?, ?, ?)", (usuario["id"], total, endereco))
        pedido_id = cursor.lastrowid

        for item_id, quantidade in itens_validos:
            banco.execute("INSERT INTO pedido_itens (pedido_id, item_id, quantidade) VALUES (?, ?, ?)", (pedido_id, item_id, quantidade))

        banco.commit()
        banco.close()
        return resposta_ok({"id": pedido_id, "total": total, "status": "AGUARDANDO"}, 201)

    except (ValueError, TypeError):
        banco.rollback()
        banco.close()
        return resposta_erro("Itens inválidos.")



@api.get("/cozinha/pedidos")
def fila_cozinha():
    banco = abrir_banco()
    pedidos = banco.execute("SELECT pedidos.*, usuarios.nome AS nome_cliente FROM pedidos JOIN usuarios ON usuarios.id = pedidos.usuario_id WHERE pedidos.status != 'PRONTO' ORDER BY pedidos.id").fetchall()
    
    resultado = []
    for pedido in pedidos:
        dados = dict(pedido)
        dados["itens"] = [dict(item) for item in banco.execute("SELECT itens_cardapio.nome, pedido_itens.quantidade FROM pedido_itens JOIN itens_cardapio ON itens_cardapio.id = pedido_itens.item_id WHERE pedido_itens.pedido_id = ?", (pedido["id"],)).fetchall()]
        resultado.append(dados)
        
    banco.close()
    return resposta_ok(resultado)

@api.patch("/cozinha/pedidos/<int:pedido_id>")
def atualizar_pedido_cozinha(pedido_id):
    dados = request.get_json(silent=True) or {}
    status = dados.get("status")
    
    if status not in ("EM_PREPARO", "PRONTO"):
        return resposta_erro("Status inválido.")

    try:
        minutos = int(dados.get("tempo_estimado", 0))
    except (ValueError, TypeError):
        return resposta_erro("Tempo estimado inválido.")

    banco = abrir_banco()
    cursor = banco.execute("UPDATE pedidos SET status = ?, tempo_estimado = ? WHERE id = ?", (status, minutos, pedido_id))
    banco.commit()
    banco.close()
    if cursor.rowcount == 0:
        return resposta_erro("Pedido não encontrado.", 404)
    return resposta_ok({"mensagem": "Pedido atualizado."})