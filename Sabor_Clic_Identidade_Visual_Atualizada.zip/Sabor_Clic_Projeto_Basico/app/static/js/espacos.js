document.addEventListener("DOMContentLoaded", async function () {
    const lista = document.querySelector("#lista-espacos");
    const filtro = document.querySelector("#filtro-tipo");
    const mensagem = document.querySelector("#mensagem-espacos");

    let espacos = [];

    // Traduz o código do tipo para um nome que aparece na página.
    function nomeDoTipo(tipo) {
        if (tipo === "DARK_KITCHEN") {
            return "Dark kitchen";
        }

        if (tipo === "BANCADA") {
            return "Bancada";
        }

        return "Cozinha compartilhada";
    }

    // Mostra os espaços recebidos do banco de dados.
    function mostrarEspacos() {
        const tipoEscolhido = filtro.value;

        const espacosFiltrados = espacos.filter(function (espaco) {
            return tipoEscolhido === "" || espaco.tipo === tipoEscolhido;
        });

        lista.innerHTML = "";

        if (espacosFiltrados.length === 0) {
            lista.textContent = "Nenhum espaço encontrado.";
            return;
        }

        espacosFiltrados.forEach(function (espaco) {
            const cartao = document.createElement("article");
            cartao.className = "cartao";

            const titulo = document.createElement("h3");
            titulo.textContent = espaco.nome;

            const tipo = document.createElement("p");
            tipo.textContent = nomeDoTipo(espaco.tipo);

            const descricao = document.createElement("p");
            descricao.textContent = espaco.descricao;

            const local = document.createElement("p");
            local.textContent = "Local: " + espaco.endereco;

            const capacidade = document.createElement("p");
            capacidade.textContent = "Capacidade: " + espaco.capacidade;

            const equipamentos = document.createElement("p");
            equipamentos.textContent = "Equipamentos: " + espaco.equipamentos;

            const valor = document.createElement("strong");
            valor.textContent = "R$ " +
                Number(espaco.valor_hora).toFixed(2).replace(".", ",") +
                " por hora";

            const link = document.createElement("a");
            link.className = "botao";
            link.href = "/reservas?espaco=" + espaco.id;
            link.textContent = "Solicitar reserva";

            cartao.append(
                titulo, tipo, descricao, local,
                capacidade, equipamentos, valor, link
            );

            lista.appendChild(cartao);
        });
    }

    try {
        espacos = await chamarApi("/api/espacos");
        mensagem.textContent = espacos.length + " espaço(s) encontrado(s).";
        mostrarEspacos();

    } catch (erro) {
        mensagem.textContent = erro.message;
    }

    filtro.addEventListener("change", mostrarEspacos);
});
