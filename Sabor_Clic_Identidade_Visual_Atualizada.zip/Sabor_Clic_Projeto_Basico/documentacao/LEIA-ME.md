# Guia rápido do projeto Sabor & Clic

A Sabor & Clic é uma empresa fictícia que administra espaços gastronômicos, como dark kitchens, cozinhas compartilhadas e bancadas equipadas. O sistema organiza as reservas desses espaços e demonstra o controle de cardápios e pedidos dos operadores gastronômicos.

## Tecnologias

- HTML e CSS para as páginas.
- JavaScript para interações, classes e comunicação com a API.
- Python com Flask para as rotas e regras.
- SQLite para guardar os dados.

## Organização

- `app/templates`: páginas HTML.
- `app/static/css`: estilos.
- `app/static/js`: scripts do navegador.
- `app/controllers`: rotas da API.
- `app/models`: conexão e inicialização do banco.
- `database`: criação, dados de exemplo, relatórios e triggers.

## Perfis de acesso

- Administrador: cadastra espaços e pratos e gerencia reservas.
- Cliente: solicita reservas, consulta cardápio e faz pedidos.
- Cozinheiro: consulta a fila e atualiza o andamento dos pedidos.

## Banco de dados

O banco possui usuários, espaços, reservas, itens de cardápio, pedidos, itens de pedido e estoque. A trigger `baixar_estoque_pedido` reduz automaticamente os ingredientes vinculados aos pratos quando um pedido é registrado. A trigger `impedir_reserva_sobreposta` evita a aprovação de reservas conflitantes.

## Observação

Os dados e pratos iniciais são fictícios e servem apenas para demonstração escolar.
