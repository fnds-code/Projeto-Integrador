import os
from flask import Flask, render_template

from app.models.database import inicializar_banco
from app.controllers.api import api


def criar_app():
    app = Flask(__name__)

    # Chave usada pelo Flask para manter a sessão de login.
    app.secret_key = os.environ.get(
        "SECRET_KEY",
        "chave-de-desenvolvimento"
    )

    # Local do arquivo do banco de dados.
    app.config["BANCO"] = os.path.join(
        app.root_path, "..", "database", "sabor_clic.db"
    )

    inicializar_banco(app.config["BANCO"])
    app.register_blueprint(api)

    @app.route("/")
    def inicio():
        return render_template("index.html")

    @app.route("/espacos")
    def pagina_espacos():
        return render_template("espacos.html")

    @app.route("/reservas")
    def pagina_reservas():
        return render_template("reservas.html")

    @app.route("/painel")
    def pagina_painel():
        return render_template("painel.html")

    @app.route("/cardapio")
    def pagina_cardapio():
        return render_template("cardapio.html")

    @app.route("/pedidos")
    def pagina_pedidos():
        return render_template("pedidos.html")

    @app.route("/cozinha")
    def pagina_cozinha():
        return render_template("cozinha.html")

    return app
