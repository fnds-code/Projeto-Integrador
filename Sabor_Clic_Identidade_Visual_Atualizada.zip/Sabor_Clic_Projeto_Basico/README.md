# Sabor & Clic

Sistema acadêmico simples para uma empresa que administra espaços gastronômicos e dark kitchens.

## Como executar

1. Instale Python 3.
2. No terminal, entre na pasta do projeto.
3. Crie o ambiente virtual:

   `python3 -m venv venv`

4. Ative o ambiente virtual no Linux:

   `source venv/bin/activate`

   No Windows, use:

   `venv\Scripts\activate`

5. Instale as dependências:

   `pip install -r requirements.txt`

6. Execute o projeto:

   `python run.py`

7. Abra `http://127.0.0.1:5000` no navegador.

O banco SQLite é criado automaticamente na primeira execução.

## Contas de demonstração

| Perfil | E-mail | Senha |
|---|---|---|
| Administrador | admin@saborclic.local | Demo123! |
| Cliente | cliente@saborclic.local | Demo123! |
| Cozinheiro | cozinha@saborclic.local | Demo123! |

Também é possível criar uma nova conta de cliente pela janela de login. O cadastro público não permite criar contas de administrador ou cozinheiro.

## Páginas

- Espaços e reservas: consulta e solicitação de horários.
- Cardápio: consulta de pratos; administrador cadastra e desativa pratos.
- Pedidos: cliente monta o carrinho, informa o endereço de entrega e acompanha o pedido.
- Cozinha: cozinheiro consulta a fila, visualiza o endereço de entrega, informa tempo e atualiza o status.
- Painel: administrador acompanha e aprova reservas.

Projeto demonstrativo. Os pratos e o estoque iniciais são dados fictícios.

## Correções desta versão

Foram removidas definições repetidas de rotas no Flask. Essa repetição impedia o servidor de iniciar. Também foram removidas páginas duplicadas no registro das rotas.

Foi acrescentado o campo de endereço na finalização dos pedidos, com exibição do endereço no histórico do cliente e na fila da cozinha. Também foi criado o cadastro público de contas de cliente, com validação de e-mail e senha.


## Ajustes de código desta versão

- As classes JavaScript usam campos privados (`#`) e a classe `Prato` e `Pedido` herdam o identificador de `Entidade`.
- O Flask verifica login e permissões em uma função executada antes das rotas da API (`before_request`).
- O login, o cadastro e a saída atualizam a interface sem recarregar a página.
- Os avisos de operações aparecem na própria página.
- O formulário de cadastro de espaços aparece somente para o administrador.
- Foram removidas regras CSS repetidas.


## Seguranca com AES (CryptoJS)

O projeto demonstra AES no navegador com a biblioteca JavaScript CryptoJS, seguindo a ideia utilizada no SkinButter.

- `base.html` contém o script com `CryptoJS.AES.encrypt()` e `CryptoJS.AES.decrypt()`, como no exemplo do SkinButter.
- Enderecos sao criptografados no navegador antes do envio; o banco armazena o texto criptografado e as telas de pedidos/cozinha o descriptografam.
- Senhas tambem sao criptografadas no navegador antes do login/cadastro; o banco compara os textos AES.
- `base.html` carrega CryptoJS antes do script de criptografia e dos demais arquivos JavaScript.

A senha das contas de demonstracao continua sendo `Demo123!`.

**Atenção ao atualizar:** esta versão altera o formato das senhas e dos endereços. Se você já executou a versão anterior, feche o servidor e renomeie ou remova o arquivo `database/sabor_clic.db` para que o banco seja recriado com os dados de demonstração no novo formato. Isso apaga os registros locais antigos.

**Observacao:** esta implementacao e didatica. A chave enviada ao navegador pode ser visualizada. O uso de AES com chave/vetor fixos para senhas nao e recomendado em sistemas reais.


## Atualizacao da identidade visual conforme o planejamento

A interface foi ajustada para seguir a identidade visual descrita no documento de planejamento do grupo:

- Cinza Profundo (`#211F20`): fundo principal, cabeçalho, navegação e rodapé.
- Lilás (`#8482FF`): botões, cartões e elementos de destaque.
- Whiskey (`#D39758`): títulos, pequenos destaques e ícones.
- Branco Frio (`#EFEDEE`): textos principais sobre fundos escuros.
- Hierarquia tipográfica: títulos com Castellar (com alternativas caso a fonte não esteja instalada) e textos com Times New Roman.
- Responsividade: mantidos os ajustes de layout para telas menores.

As funcionalidades existentes — login, cadastro, painel administrativo, espaços, reservas, cardápio, pedidos, fila da cozinha, banco de dados, rotas da API e demonstração AES com CryptoJS — foram preservadas. Esta atualização se concentra na apresentação visual, sem remover recursos funcionais.
